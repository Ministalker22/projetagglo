<!-- 
********************************************
** Nom: Yvetot                            **
** Prénom: Quentin                        **
** Date de création: 07/02/2022           **
** Dernière modification: Moi, 07/03/2022 **
********************************************
-->
<!DOCTYPE html> 
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="stylebat.css">
  <title>Erreur</title>
</head>
<body>

<!-- fond barre de navigation -->
  <div id="bande_horizontale_top">
  
<!-- barre de navigation centrer -->
<center>
  <nav>
        <ul class="menu">
          <li><a href="index.php">ACCUEIL</a></li>
          <li><a href="BATTERIES.php">BATTERIES</a></li>
           <li>
              HISTORIQUE
            <ul class="sub-menu">
              <a href="7jours.php"><li>7 Jours</li></a>
              </ul>
            </li>
           <li><a href="POSITION_GPS.php">POSITION GPS</a></li>
          <li><a href="connect.php">ACCES BDD</a></li>
        </ul>
        </nav><!-- fin barre de navigation -->

</div> <!-- fin fond barre de navigation -->

</center>
</body>
</html>